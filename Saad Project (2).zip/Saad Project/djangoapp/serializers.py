from rest_framework import serializers
from .models import Dealer, DealerReview

class DealerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Dealer
        fields = '__all__'


class ReviewSerializer(serializers.ModelSerializer):
    class Meta:
        model = DealerReview
        fields = '__all__'
from django.apps import AppConfig


class DjangoappConfig(AppConfig):
    name = 'djangoapp'
